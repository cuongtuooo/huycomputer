import AdminDashboard from "@/components/admin/dashboard";

const DashBoardPage = () => {
    return (
        <div>
            <AdminDashboard />
        </div>
    )
}

export default DashBoardPage;
