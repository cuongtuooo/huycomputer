import TableOrder from "@/components/admin/order";

const ManageOrderPage = () => {
    return (
        <div>
            <TableOrder />
        </div>
    )
}

export default ManageOrderPage;

